import os
import uuid
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app import db
from app.models import Report, Category, ReportUpdate, User
from app.utils.decorators import role_required
from app.utils.notifications import create_notification, notify_admins, notify_maintenance

student_bp = Blueprint('student', __name__)


def allowed_file(filename):
    allowed = current_app.config.get('ALLOWED_EXTENSIONS', {'png', 'jpg', 'jpeg', 'gif', 'webp'})
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed


@student_bp.route('/dashboard')
@login_required
def dashboard():
    total = Report.query.filter_by(user_id=current_user.id).count()
    pending = Report.query.filter_by(user_id=current_user.id, status='submitted').count()
    in_progress = Report.query.filter(
        Report.user_id == current_user.id,
        Report.status.in_(['assigned', 'in_progress'])
    ).count()
    resolved = Report.query.filter_by(user_id=current_user.id, status='resolved').count()
    recent_reports = Report.query.filter_by(user_id=current_user.id).order_by(Report.created_at.desc()).limit(10).all()
    return render_template('student/dashboard.html',
        total=total, pending=pending, in_progress=in_progress, resolved=resolved,
        reports=recent_reports)


@student_bp.route('/submit-report', methods=['GET', 'POST'])
@login_required
def submit_report():
    categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()

    if request.method == 'POST':
        category_id = request.form.get('category_id', '')
        custom_category = request.form.get('custom_category', '').strip()
        location = request.form.get('location', '').strip()
        description = request.form.get('description', '').strip()
        urgency = request.form.get('urgency', 'medium')

        errors = []

        # Handle custom category: either use existing dropdown or create/find custom one
        if category_id == 'other':
            if not custom_category or len(custom_category) < 2:
                errors.append('Please enter a custom category name (at least 2 characters).')
            else:
                # Check if a category with this name already exists (case-insensitive)
                existing = Category.query.filter(db.func.lower(Category.name) == custom_category.lower()).first()
                if existing:
                    category_id = existing.id
                else:
                    new_cat = Category(name=custom_category, icon='📝', is_active=True)
                    db.session.add(new_cat)
                    db.session.flush()  # Get the ID without committing
                    category_id = new_cat.id
        else:
            category_id = int(category_id) if category_id else None
            if not category_id or not Category.query.get(category_id):
                errors.append('Please select a valid category.')

        if len(location) < 3 or len(location) > 200:
            errors.append('Location must be between 3 and 200 characters.')
        if len(description) < 20 or len(description) > 1000:
            errors.append('Description must be between 20 and 1000 characters.')
        if urgency not in ('low', 'medium', 'high'):
            errors.append('Invalid urgency level.')

        photo_path = None
        photo = request.files.get('photo')
        if photo and photo.filename:
            if not allowed_file(photo.filename):
                errors.append('Photo must be JPG, PNG, GIF or WebP.')
            else:
                filename = f"{uuid.uuid4().hex}_{secure_filename(photo.filename)}"
                photo_path = filename
                photo.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))

        if errors:
            for e in errors:
                flash(e, 'danger')
            return render_template('student/submit_report.html', categories=categories)

        report = Report(
            user_id=current_user.id, category_id=category_id,
            location=location, description=description,
            urgency=urgency, photo_path=photo_path, status='submitted'
        )
        db.session.add(report)
        db.session.commit()

        update = ReportUpdate(
            report_id=report.id, updated_by=current_user.id,
            old_status=None, new_status='submitted', note='Report submitted'
        )
        db.session.add(update)
        db.session.commit()

        cat = Category.query.get(category_id)
        urgency_emoji = {'high': '🔴', 'medium': '🟡', 'low': '🟢'}.get(urgency, '')
        notify_admins(report.id, f"New report #{report.id} submitted ({urgency_emoji} {urgency.capitalize()}) — {cat.icon} {cat.name}")
        if urgency == 'high':
            notify_maintenance(report.id, f"⚠️ High priority: {cat.name} issue at {location}")

        flash('Report submitted successfully!', 'success')
        return redirect(url_for('student.dashboard'))

    return render_template('student/submit_report.html', categories=categories)


@student_bp.route('/my-reports')
@login_required
def track_reports():
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', '')
    category_filter = request.args.get('category', '', type=str)
    urgency_filter = request.args.get('urgency', '')

    query = Report.query.filter_by(user_id=current_user.id)
    if status_filter:
        query = query.filter_by(status=status_filter)
    if category_filter:
        query = query.filter_by(category_id=int(category_filter))
    if urgency_filter:
        query = query.filter_by(urgency=urgency_filter)

    reports = query.order_by(Report.created_at.desc()).paginate(page=page, per_page=10, error_out=False)
    categories = Category.query.filter_by(is_active=True).all()
    return render_template('student/track_reports.html',
        reports=reports, categories=categories,
        status_filter=status_filter, category_filter=category_filter, urgency_filter=urgency_filter)


@student_bp.route('/report/<int:report_id>')
@login_required
def report_detail(report_id):
    report = Report.query.get_or_404(report_id)
    if current_user.role == 'student' and report.user_id != current_user.id:
        flash('You do not have permission to view this report.', 'danger')
        return redirect(url_for('student.dashboard'))
    updates = report.updates.order_by(ReportUpdate.timestamp.asc()).all()
    return render_template('student/report_detail.html', report=report, updates=updates)
