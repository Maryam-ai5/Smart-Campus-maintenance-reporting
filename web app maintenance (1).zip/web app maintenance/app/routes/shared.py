from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from app.models import Notification, Report, Category, User

shared_bp = Blueprint('shared', __name__)


@shared_bp.route('/notifications')
@login_required
def notifications():
    filter_type = request.args.get('filter', 'all')
    query = Notification.query.filter_by(user_id=current_user.id)
    if filter_type == 'unread':
        query = query.filter_by(is_read=False)
    notifs = query.order_by(Notification.created_at.desc()).all()
    unread = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
    return render_template('notifications.html', notifications=notifs, unread=unread, filter_type=filter_type)


@shared_bp.route('/notifications/mark-read/<int:notif_id>', methods=['POST'])
@login_required
def mark_read(notif_id):
    notif = Notification.query.get_or_404(notif_id)
    if notif.user_id != current_user.id:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('shared.notifications'))
    notif.is_read = True
    db.session.commit()
    return redirect(url_for('shared.notifications'))


@shared_bp.route('/notifications/mark-all-read', methods=['POST'])
@login_required
def mark_all_read():
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
    db.session.commit()
    flash('All notifications marked as read.', 'success')
    return redirect(url_for('shared.notifications'))


@shared_bp.route('/search')
@login_required
def search():
    q = request.args.get('q', '').strip()
    status = request.args.get('status', '')
    category = request.args.get('category', '')
    urgency = request.args.get('urgency', '')
    page = request.args.get('page', 1, type=int)

    query = Report.query
    if current_user.role == 'student':
        query = query.filter_by(user_id=current_user.id)

    if q:
        query = query.filter(db.or_(
            Report.description.ilike(f'%{q}%'),
            Report.location.ilike(f'%{q}%')
        ))
    if status:
        query = query.filter_by(status=status)
    if category:
        query = query.filter_by(category_id=int(category))
    if urgency:
        query = query.filter_by(urgency=urgency)

    results = query.order_by(Report.created_at.desc()).paginate(page=page, per_page=10, error_out=False)
    categories = Category.query.filter_by(is_active=True).all()
    return render_template('search.html', results=results, categories=categories,
        q=q, status_filter=status, category_filter=category, urgency_filter=urgency)


@shared_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        action = request.form.get('action', '')

        if action == 'update_profile':
            name = request.form.get('name', '').strip()
            if name and 2 <= len(name) <= 100:
                current_user.name = name
                db.session.commit()
                flash('Profile updated successfully.', 'success')
            else:
                flash('Name must be between 2 and 100 characters.', 'danger')

        elif action == 'change_password':
            current_pw = request.form.get('current_password', '')
            new_pw = request.form.get('new_password', '')
            confirm_pw = request.form.get('confirm_password', '')

            if not check_password_hash(current_user.password_hash, current_pw):
                flash('Current password is incorrect.', 'danger')
            elif len(new_pw) < 8:
                flash('New password must be at least 8 characters.', 'danger')
            elif new_pw != confirm_pw:
                flash('Passwords do not match.', 'danger')
            else:
                current_user.password_hash = generate_password_hash(new_pw)
                db.session.commit()
                flash('Password changed successfully.', 'success')

        return redirect(url_for('shared.profile'))

    total_reports = Report.query.filter_by(user_id=current_user.id).count()
    resolved_reports = Report.query.filter_by(user_id=current_user.id, status='resolved').count()
    last_report = Report.query.filter_by(user_id=current_user.id).order_by(Report.created_at.desc()).first()
    return render_template('profile.html', total_reports=total_reports, resolved_reports=resolved_reports, last_report=last_report)
