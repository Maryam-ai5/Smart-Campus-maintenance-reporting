# 🏫 Smart Campus Maintenance Reporting System (CampusFix)

## Project Overview

The **Smart Campus Maintenance Reporting System** (branded **CampusFix** in the UI) is a centralized web-based platform that replaces verbal, phone, email, and paper-based maintenance reporting with a streamlined digital workflow. It enables students, staff, maintenance teams, and administrators to submit, track, assign, and resolve campus maintenance issues through a single unified interface.

This document serves two purposes:
1. **Product overview** — what the system does and why it exists
2. **Student learning guide** — how the code is organized, how data flows, and what each file is responsible for

---

## Problem Statement

> No centralized maintenance reporting exists on campus.  
> Reports are disorganized, slow to reach the relevant team, and often ignored.  
> There is no tracking, no accountability, and no feedback loop for the reporter.

**Key Statistics from Survey:**
- **77.4%** of students want an electronic reporting system
- **10%** of students currently don't report issues at all
- The top issue type is **Electrical (41.9%)**

---

## Tech Stack

| Layer        | Technology              | Purpose in This Project                                      |
|--------------|-------------------------|--------------------------------------------------------------|
| **Backend**  | Python · Flask 3.1      | HTTP routes, business logic, form handling, file uploads     |
| **ORM**      | Flask-SQLAlchemy 3.1    | Maps Python classes to SQLite tables; runs queries           |
| **Database** | SQLite                  | Single file (`instance/campus.db`); no separate DB server  |
| **Auth**     | Flask-Login 0.6         | Session cookies; remembers who is logged in                  |
| **Security** | Flask-WTF (CSRF)        | Protects forms from cross-site request forgery               |
| **Passwords**| Werkzeug                | `generate_password_hash` / `check_password_hash`             |
| **Frontend** | Bootstrap 5 + Jinja2    | Responsive UI; server-rendered HTML templates                |
| **Charts**   | Chart.js 4.4            | Admin analytics dashboards                                 |
| **Icons**    | Bootstrap Icons         | Sidebar and UI icons                                         |

---

## User Roles

| Role                | Access Level | Key Capabilities                                         |
|---------------------|-------------|----------------------------------------------------------|
| **Student / Staff** | Basic        | Submit reports, track status, receive notifications      |
| **Maintenance Team**| Operational  | View all tickets, update status, add resolution notes    |
| **Admin**           | Full         | Manage users, view analytics, configure categories       |

**How roles are enforced in code:**  
The `@role_required('admin')` decorator in `app/utils/decorators.py` checks `current_user.role` after `@login_required`. If the role does not match, Flask returns HTTP **403 Forbidden**.

---

## Issue Categories

Categories are stored in the database (`categories` table), not hard-coded. Default seed data includes:

| Category   | Icon | Typical Issues                                      |
|------------|------|-----------------------------------------------------|
| Electrical | ⚡   | Wiring, sockets, lighting, power strips             |
| HVAC       | ❄️   | Air conditioning, temperature, ventilation          |
| Plumbing   | 🔧   | Leaks, pipes, drainage, water pressure              |
| Furniture  | 🪑   | Chairs, tables, desks, screens                      |
| Cleaning   | 🧹   | Hygiene, trash, cafeteria cleanliness               |

Students can also pick **"Other"** and type a custom category; the app creates a new `Category` row if that name does not already exist.

---

## Report Lifecycle

```
Submitted → Assigned → In Progress → Resolved
```

| Status        | Meaning                                              | Who typically sets it   |
|---------------|------------------------------------------------------|-------------------------|
| `submitted`   | New report; waiting for maintenance                  | Student (on submit)     |
| `assigned`    | Maintenance team has taken ownership                 | Maintenance / Admin     |
| `in_progress` | Work has started on site                             | Maintenance / Admin     |
| `resolved`    | Issue fixed and verified                             | Maintenance / Admin     |

**What happens on each status change:**
1. The `reports.status` column is updated
2. A row is inserted into `report_updates` (audit trail / timeline)
3. The reporter receives a **notification** via `create_notification()`

---

## For Students: How the Application Works

### The Big Picture (Request → Response)

When you open `http://localhost:5000` in a browser:

```
Browser Request
      ↓
run.py  →  create_app()  in  app/__init__.py
      ↓
Flask matches URL to a route function (in app/routes/*.py)
      ↓
Route queries/updates the database via SQLAlchemy models
      ↓
Route calls render_template('some_page.html', data=...)
      ↓
Jinja2 fills in HTML with Python variables
      ↓
Browser receives complete HTML page
```

This is a **traditional server-rendered web app** — not a separate React/Vue SPA. The server builds each page before sending it.

### Application Factory Pattern

`app/__init__.py` defines `create_app()`:

- Creates the Flask instance
- Loads settings from `config.py` (`SECRET_KEY`, database path, upload folder)
- Initializes extensions: `db`, `login_manager`, `csrf`
- Registers five **blueprints** (modular route groups)
- Creates database tables if they do not exist (`db.create_all()`)
- Injects `unread_notification_count` into every template (for the bell badge)

`run.py` calls `create_app()`, seeds demo data on first run, then runs `app.run(debug=True, port=5000)`.

### Blueprints (Route Modules)

Flask **blueprints** split routes by feature. Each blueprint is a mini-app registered in `create_app()`:

| Blueprint file      | URL prefix (implicit) | Responsibility                          |
|---------------------|------------------------|-----------------------------------------|
| `routes/auth.py`    | `/`, `/login`, etc.    | Login, register, logout, root redirect  |
| `routes/student.py` | `/dashboard`, etc.     | Student dashboard, submit, track reports|
| `routes/maintenance.py` | `/maintenance/... | Maintenance work panel, status updates  |
| `routes/admin.py`   | `/admin/...`           | Analytics, users, categories            |
| `routes/shared.py`  | `/notifications`, etc. | Notifications, search, profile (all roles) |

### Complete Route Map

| Method | URL | Function | Who can access |
|--------|-----|----------|----------------|
| GET | `/` | `auth.index` | Everyone — redirects to login or role dashboard |
| GET/POST | `/login` | `auth.login` | Guests |
| GET/POST | `/register` | `auth.register` | Guests (creates `student` only) |
| GET | `/logout` | `auth.logout` | Logged-in users |
| GET | `/dashboard` | `student.dashboard` | Logged-in (student UI) |
| GET/POST | `/submit-report` | `student.submit_report` | Logged-in |
| GET | `/my-reports` | `student.track_reports` | Logged-in |
| GET | `/report/<id>` | `student.report_detail` | Owner, or maintenance/admin |
| GET | `/maintenance/panel` | `maintenance.panel` | `maintenance`, `admin` |
| POST | `/maintenance/update-status/<id>` | `maintenance.update_status` | `maintenance`, `admin` |
| GET | `/admin/dashboard` | `admin.dashboard` | `admin` |
| GET | `/admin/users` | `admin.users` | `admin` |
| POST | `/admin/users/add` | `admin.add_user` | `admin` |
| POST | `/admin/users/<id>/role` | `admin.change_role` | `admin` |
| POST | `/admin/users/<id>/toggle` | `admin.toggle_user` | `admin` |
| GET | `/admin/categories` | `admin.categories` | `admin` |
| POST | `/admin/categories/add` | `admin.add_category` | `admin` |
| POST | `/admin/categories/<id>/toggle` | `admin.toggle_category` | `admin` |
| GET | `/notifications` | `shared.notifications` | Logged-in |
| POST | `/notifications/mark-read/<id>` | `shared.mark_read` | Owner of notification |
| POST | `/notifications/mark-all-read` | `shared.mark_all_read` | Logged-in |
| GET | `/search` | `shared.search` | Logged-in (students see only their reports) |
| GET/POST | `/profile` | `shared.profile` | Logged-in |

### Authentication Flow (Step by Step)

1. **Registration** (`auth.register`):  
   - Validates name, email, password (min 8 chars), confirm password  
   - Hashes password with `generate_password_hash()` — never stores plain text  
   - Creates user with `role='student'` only (maintenance/admin created by admin)

2. **Login** (`auth.login`):  
   - Finds user by email  
   - `check_password_hash(stored_hash, typed_password)`  
   - `login_user(user, remember=remember)` — Flask-Login sets a secure session cookie  
   - Redirects to the correct dashboard based on `user.role`

3. **Protected pages**:  
   - `@login_required` — redirects to `/login` if not authenticated  
   - `@role_required('admin')` — returns 403 if wrong role

4. **Session loading**:  
   - On each request, Flask-Login calls `load_user(user_id)` in `models.py` to reload the `User` from the database

### Submitting a Report (End-to-End)

When a student submits the form at `/submit-report`:

1. **Validation** — category, location (3–200 chars), description (20–1000 chars), urgency (`low`/`medium`/`high`)
2. **Optional photo** — saved to `app/static/uploads/` with a UUID prefix; only `png`, `jpg`, `jpeg`, `gif`, `webp`; max 5 MB (`config.py`)
3. **Database** — new `Report` row with `status='submitted'`
4. **Timeline** — `ReportUpdate` row: `None → submitted`, note "Report submitted"
5. **Notifications**:
   - All **admins** get: `New report #N submitted (🔴 High) — ⚡ Electrical`
   - If urgency is **high**, all **maintenance** users get an alert too
6. **Redirect** — flash message + redirect to student dashboard

### Maintenance Status Update (End-to-End)

When maintenance posts to `/maintenance/update-status/<report_id>`:

1. Reads `status` and optional `note` from the form
2. Saves old status, writes new status to `reports`
3. Appends `ReportUpdate` with `old_status → new_status`
4. Calls `create_notification(report.user_id, ...)` so the **student who filed** the report is notified
5. Redirects back to the panel with a success flash

### Notification System

`app/utils/notifications.py` provides:

| Function | What it does |
|----------|--------------|
| `create_notification(user_id, report_id, message)` | One notification for one user |
| `notify_admins(report_id, message)` | Loops all active admins |
| `notify_maintenance(report_id, message)` | Loops all active maintenance staff |
| `get_unread_count(user_id)` | Used in navbar badge via context processor |

Notifications are **in-app only** (database rows), not email or SMS.

---

## Database Schema (Implemented)

### Entity Relationship (Conceptual)

```
users ─────────────┬──────────────── reports
  │                │                      │
  │                │                      ├── category_id → categories
  │                │                      │
  └── notifications┘                      └── report_updates
         (also links to reports)                (updated_by → users)
```

### Table Details

#### `users`
| Column | Type | Notes |
|--------|------|-------|
| `id` | Integer PK | Auto-increment |
| `name` | String(100) | Display name |
| `email` | String(120) | Unique login identifier |
| `password_hash` | String(256) | Werkzeug hash, not plain password |
| `role` | String(20) | `student`, `maintenance`, or `admin` |
| `is_active_user` | Boolean | Admin can deactivate accounts |
| `created_at` | DateTime | UTC timestamp |

**Flask-Login integration:** `User` inherits `UserMixin`. The `is_active` property maps to `is_active_user` so deactivated users cannot log in.

#### `categories`
| Column | Type | Notes |
|--------|------|-------|
| `id` | Integer PK | |
| `name` | String(100) | Unique |
| `icon` | String(10) | Emoji shown in UI |
| `description` | String(255) | |
| `is_active` | Boolean | Inactive categories hidden from submit form |

#### `reports`
| Column | Type | Notes |
|--------|------|-------|
| `id` | Integer PK | Shown as "Report #N" in UI |
| `user_id` | FK → users | Who submitted |
| `category_id` | FK → categories | Issue type |
| `location` | String(200) | e.g. "Block A, Room 102" |
| `description` | Text | Detailed problem description |
| `urgency` | String(20) | `low`, `medium`, `high` |
| `photo_path` | String(255) | Filename only; file in `static/uploads/` |
| `status` | String(20) | Lifecycle state |
| `created_at`, `updated_at` | DateTime | `updated_at` auto-updates on change |

**Helper properties on `Report`:** `status_step` (1–4 for progress bar), `status_label`, `urgency_label`.

#### `report_updates`
| Column | Type | Notes |
|--------|------|-------|
| `id` | Integer PK | |
| `report_id` | FK → reports | |
| `updated_by` | FK → users | Who made the change |
| `old_status`, `new_status` | String(20) | Audit trail |
| `note` | Text | Optional comment |
| `timestamp` | DateTime | When change occurred |

#### `notifications`
| Column | Type | Notes |
|--------|------|-------|
| `id` | Integer PK | |
| `user_id` | FK → users | Recipient |
| `report_id` | FK → reports | Nullable link to related report |
| `message` | Text | Display text |
| `is_read` | Boolean | Unread count for badge |
| `created_at` | DateTime | |

---

## Frontend Architecture

### Template Inheritance

All pages extend `app/templates/base.html`:

- **Logged out:** shows `auth_content` block (login/register) in a centered auth layout
- **Logged in:** sidebar navigation + top navbar + `content` block

The sidebar links change based on `current_user.role` (Jinja `{% if %}`).

### Key Template Files

| Template | Purpose |
|----------|---------|
| `auth/login.html`, `auth/register.html` | Public auth forms |
| `student/dashboard.html` | Stats cards + recent reports table |
| `student/submit_report.html` | Issue submission form + photo preview |
| `student/track_reports.html` | Paginated list with filters |
| `student/report_detail.html` | Full report + status timeline |
| `maintenance/panel.html` | All campus reports + status update forms |
| `admin/dashboard.html` | Charts (Chart.js) + KPI cards |
| `admin/users.html` | User CRUD, role change, activate/deactivate |
| `admin/categories.html` | Category management |
| `notifications.html` | Notification inbox |
| `search.html` | Cross-report search |
| `profile.html` | Edit name, change password, stats |

### Static Assets

| File | Purpose |
|------|---------|
| `static/css/style.css` | Custom theme: sidebar, cards, badges, urgency colors |
| `static/js/app.js` | Mobile sidebar toggle, auto-dismiss alerts, image preview |
| `static/uploads/` | User-uploaded report photos (created at startup) |

### Flash Messages

Routes call `flash('message', 'category')` where category is `success`, `danger`, `warning`, or `info`.  
`base.html` renders them as Bootstrap alerts; `app.js` auto-closes them after 5 seconds.

---

## Actual Folder Structure

```
web app maintenance/
├── app/
│   ├── __init__.py              # App factory, extensions, blueprints, DB init
│   ├── models.py                # User, Category, Report, ReportUpdate, Notification
│   ├── routes/
│   │   ├── auth.py              # Login, register, logout, /
│   │   ├── student.py           # Dashboard, submit, track, detail
│   │   ├── maintenance.py       # Panel, status updates
│   │   ├── admin.py             # Dashboard, users, categories
│   │   └── shared.py            # Notifications, search, profile
│   ├── templates/               # Jinja2 HTML (see table above)
│   ├── static/
│   │   ├── css/style.css
│   │   ├── js/app.js
│   │   └── uploads/             # Report photos (runtime)
│   └── utils/
│       ├── decorators.py        # @role_required
│       └── notifications.py     # Notification helpers
├── instance/
│   └── campus.db                # SQLite database (created on first run)
├── config.py                    # SECRET_KEY, DB URI, upload limits
├── run.py                       # Entry point + database seeding
├── requirements.txt             # Python dependencies
└── project_overview.md          # This file
```

> **Note:** The `migrations/` and `tests/` folders from the original plan are not yet implemented. Schema changes currently use `db.create_all()` on startup.

---

## How to Run the Project

### Prerequisites
- Python 3.10+ recommended
- Virtual environment (optional but recommended)

### Steps

```bash
# 1. Navigate to project folder
cd "j:\rubina\web app maintenance"

# 2. Create and activate virtual environment (if not done)
python -m venv venv
venv\Scripts\activate        # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Start the server
python run.py
```

Open **http://localhost:5000** in your browser.

On **first run**, `run.py` seeds the database with demo users, categories, sample reports, and notifications. If `instance/campus.db` already has users, seeding is skipped.

### Demo Login Accounts

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@campus.edu` | `admin123` |
| Student | `student@campus.edu` | `student123` |
| Student | `sara@campus.edu` | `student123` |
| Maintenance | `maintenance@campus.edu` | `maintenance123` |
| Maintenance | `hassan@campus.edu` | `maintenance123` |

---

## Security Features (What to Notice as a Developer)

| Feature | Where | Why it matters |
|---------|-------|----------------|
| Password hashing | `auth.py`, `shared.py` | Passwords never stored in plain text |
| CSRF protection | Flask-WTF in `__init__.py` | Forms need valid CSRF token |
| `secure_filename()` | `student.py` | Prevents path traversal on uploads |
| UUID file names | `student.py` | Avoids overwriting files |
| Role checks | `decorators.py` | Prevents students from accessing `/admin` |
| Ownership check | `student.report_detail` | Students cannot view others' reports |
| `login_required` | Most routes | Unauthenticated users redirected to login |
| `MAX_CONTENT_LENGTH` | `config.py` | Rejects uploads larger than 5 MB |

---

## Key Concepts Glossary (For Beginners)

| Term | Meaning in this project |
|------|-------------------------|
| **Route** | A URL path mapped to a Python function |
| **Blueprint** | A group of related routes in its own file |
| **ORM** | Object-Relational Mapping — use Python classes instead of raw SQL |
| **Model** | A Python class = one database table (`User`, `Report`, etc.) |
| **Migration** | Scripted database schema changes (not used yet; we use `create_all`) |
| **Session** | Server-side data tied to the logged-in user (via cookie) |
| **Template** | HTML file with `{{ variables }}` filled by Jinja2 |
| **Flash message** | One-time message shown on the next page after redirect |
| **Foreign Key (FK)** | Column that references another table's primary key |
| **Pagination** | Splitting long lists into pages (`paginate(page=1, per_page=10)`) |

---

## Data Flow Diagrams

### Student submits a report

```mermaid
sequenceDiagram
    participant S as Student Browser
    participant F as Flask (student.py)
    participant DB as SQLite
    participant N as notifications.py

    S->>F: POST /submit-report (form + optional photo)
    F->>F: Validate fields, save photo
    F->>DB: INSERT reports, report_updates
    F->>N: notify_admins()
    alt urgency is high
        F->>N: notify_maintenance()
    end
    F->>S: Redirect /dashboard + flash success
```

### Maintenance resolves a report

```mermaid
sequenceDiagram
    participant M as Maintenance Browser
    participant F as Flask (maintenance.py)
    participant DB as SQLite
    participant S as Student (notification)

    M->>F: POST /maintenance/update-status/5
    F->>DB: UPDATE reports.status
    F->>DB: INSERT report_updates
    F->>DB: INSERT notifications (reporter)
    F->>M: Redirect panel + flash success
    Note over S: Student sees badge on next page load
```

---

## Pages Implemented vs. Original Plan

| # | Page | Template | Status |
|---|------|----------|--------|
| 1 | Login & Registration | `auth/login.html`, `auth/register.html` | ✅ Done |
| 2 | Student Dashboard | `student/dashboard.html` | ✅ Done |
| 3 | Issue Submission Form | `student/submit_report.html` | ✅ Done |
| 4 | Report Detail View | `student/report_detail.html` | ✅ Done |
| 5 | Report Tracking | `student/track_reports.html` | ✅ Done |
| 6 | Maintenance Panel | `maintenance/panel.html` | ✅ Done |
| 7 | Admin Dashboard | `admin/dashboard.html` | ✅ Done |
| 8 | User Management | `admin/users.html` | ✅ Done |
| 9 | Category Management | `admin/categories.html` | ✅ Done |
| 10 | Notifications | `notifications.html` | ✅ Done |
| 11 | Search & Filter | `search.html` | ✅ Done |
| 12 | Profile & Settings | `profile.html` | ✅ Done |

---

## Suggested Learning Path for Students

1. **Run the app** — log in as each role and click through every page
2. **Read `config.py` and `run.py`** — understand how the app starts
3. **Read `app/__init__.py`** — see how Flask is assembled
4. **Read `app/models.py`** — understand the data model
5. **Trace one feature end-to-end** — e.g. open `submit_report.html`, find the form action, follow `student.submit_report()` in `student.py`
6. **Read `decorators.py` and `notifications.py`** — small files, high impact
7. **Compare `auth.py` login flow** with Flask-Login documentation
8. **Modify something small** — e.g. add a new flash message, change a validation rule, add a column to a template

---

## Success Metrics

| Metric           | Target                          |
|------------------|---------------------------------|
| Response Time    | Measurably reduced              |
| Reports Ignored  | Zero tolerance                  |
| User Satisfaction| > 80% agree it's easy to use    |
| Adoption         | Replace all manual methods      |

---

## Project Methodology

- **Agile** with weekly sprints
- Team meetings: Tuesday / Wednesday
- Tools: VS Code, Git, manual testing

---

## Future Improvements (Not Yet Built)

- Automated unit/integration tests (`tests/` folder)
- Database migrations with Flask-Migrate (`migrations/`)
- Email notifications when status changes
- Admin ability to **reopen** resolved tickets
- Assign specific maintenance worker to a ticket (currently all see all tickets)
- API endpoints for mobile app

---

*Smart Campus Maintenance Reporting System · CampusFix · Implementation Guide · May 2026*
