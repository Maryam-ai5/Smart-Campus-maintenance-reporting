from app import create_app, db
from app.models import User, Category, Report, ReportUpdate, Notification
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
import random

app = create_app()


def seed_database():
    """Seed the database with default data on first run."""
    with app.app_context():
        # Skip if already seeded
        if User.query.first():
            return

        print("🌱 Seeding database...")

        # --- Users ---
        admin = User(name='Admin User', email='admin@campus.edu',
                     password_hash=generate_password_hash('admin123'), role='admin')
        student = User(name='Ahmed Khan', email='student@campus.edu',
                       password_hash=generate_password_hash('student123'), role='student')
        student2 = User(name='Sara Ali', email='sara@campus.edu',
                        password_hash=generate_password_hash('student123'), role='student')
        maint = User(name='Ali Technician', email='maintenance@campus.edu',
                     password_hash=generate_password_hash('maintenance123'), role='maintenance')
        maint2 = User(name='Hassan Engineer', email='hassan@campus.edu',
                      password_hash=generate_password_hash('maintenance123'), role='maintenance')

        db.session.add_all([admin, student, student2, maint, maint2])
        db.session.commit()

        # --- Categories ---
        cats = [
            Category(name='Electrical', icon='⚡', description='Faults in wiring, sockets, lighting'),
            Category(name='HVAC', icon='❄️', description='Air conditioning and temperature control'),
            Category(name='Plumbing', icon='🔧', description='Water leaks, pipes, drainage'),
            Category(name='Furniture', icon='🪑', description='Chairs, tables, screens'),
            Category(name='Cleaning', icon='🧹', description='Hygiene and cleanliness'),
        ]
        db.session.add_all(cats)
        db.session.commit()

        # --- Sample Reports ---
        now = datetime.utcnow()
        samples = [
            {'user': student, 'cat': cats[0], 'loc': 'Block A, Room 102', 'desc': 'Power outlet near the whiteboard is not working. Students cannot charge laptops during lectures which is very inconvenient.',
             'urg': 'high', 'status': 'assigned', 'days_ago': 5},
            {'user': student, 'cat': cats[1], 'loc': 'Library, 2nd Floor', 'desc': 'Air conditioning unit making loud rattling noise and not cooling effectively. Temperature is unbearable for studying.',
             'urg': 'medium', 'status': 'in_progress', 'days_ago': 4},
            {'user': student2, 'cat': cats[2], 'loc': 'Building B, Washroom 3', 'desc': 'Water leak from the ceiling pipe in the third-floor washroom. Water is pooling on the floor creating a slip hazard.',
             'urg': 'high', 'status': 'submitted', 'days_ago': 2},
            {'user': student, 'cat': cats[3], 'loc': 'Lecture Hall 201', 'desc': 'Several chairs in rows 3 and 4 have broken armrests. The desk portions are also unstable and cannot hold notebooks properly.',
             'urg': 'low', 'status': 'resolved', 'days_ago': 10},
            {'user': student2, 'cat': cats[4], 'loc': 'Cafeteria', 'desc': 'The cafeteria tables have not been cleaned for days. Food stains and trash are accumulating, making it unhygienic for eating.',
             'urg': 'medium', 'status': 'submitted', 'days_ago': 1},
            {'user': student, 'cat': cats[0], 'loc': 'Lab 305, Computer Science', 'desc': 'Three workstation monitors are flickering continuously. The power strips appear to be overloaded and may be a fire hazard.',
             'urg': 'high', 'status': 'in_progress', 'days_ago': 3},
            {'user': student2, 'cat': cats[1], 'loc': 'Block C, Room 401', 'desc': 'The AC unit is leaking water onto the floor near the entrance. It creates puddles every morning that students have to walk through.',
             'urg': 'medium', 'status': 'assigned', 'days_ago': 6},
            {'user': student, 'cat': cats[2], 'loc': 'Sports Complex, Shower Area', 'desc': 'Two shower heads are broken and water pressure is very low in the remaining ones. The drainage is also clogged.',
             'urg': 'low', 'status': 'resolved', 'days_ago': 14},
        ]

        for s in samples:
            created = now - timedelta(days=s['days_ago'], hours=random.randint(1, 12))
            report = Report(
                user_id=s['user'].id, category_id=s['cat'].id,
                location=s['loc'], description=s['desc'],
                urgency=s['urg'], status=s['status'],
                created_at=created, updated_at=created
            )
            db.session.add(report)
            db.session.commit()

            # Add timeline updates
            upd = ReportUpdate(report_id=report.id, updated_by=s['user'].id,
                               old_status=None, new_status='submitted',
                               note='Report submitted', timestamp=created)
            db.session.add(upd)

            if s['status'] in ('assigned', 'in_progress', 'resolved'):
                t = created + timedelta(hours=random.randint(2, 8))
                upd2 = ReportUpdate(report_id=report.id, updated_by=maint.id,
                                    old_status='submitted', new_status='assigned',
                                    note='Assigned to maintenance team', timestamp=t)
                db.session.add(upd2)
                report.updated_at = t

            if s['status'] in ('in_progress', 'resolved'):
                t = created + timedelta(days=1, hours=random.randint(1, 6))
                upd3 = ReportUpdate(report_id=report.id, updated_by=maint.id,
                                    old_status='assigned', new_status='in_progress',
                                    note='Work has begun on this issue', timestamp=t)
                db.session.add(upd3)
                report.updated_at = t

            if s['status'] == 'resolved':
                t = created + timedelta(days=2, hours=random.randint(1, 6))
                upd4 = ReportUpdate(report_id=report.id, updated_by=maint.id,
                                    old_status='in_progress', new_status='resolved',
                                    note='Issue has been fixed and verified', timestamp=t)
                db.session.add(upd4)
                report.updated_at = t

            db.session.commit()

        # --- Sample Notifications ---
        notifs = [
            Notification(user_id=student.id, report_id=1, message='Report #1 has been assigned to maintenance team', is_read=False, created_at=now - timedelta(hours=5)),
            Notification(user_id=student.id, report_id=2, message='Report #2 is now In Progress', is_read=False, created_at=now - timedelta(hours=3)),
            Notification(user_id=student.id, report_id=4, message='Report #4 has been resolved!', is_read=True, created_at=now - timedelta(days=2)),
            Notification(user_id=admin.id, report_id=3, message='New report #3 submitted (🔴 High) — 🔧 Plumbing', is_read=False, created_at=now - timedelta(hours=2)),
            Notification(user_id=maint.id, report_id=3, message='⚠️ High priority: Plumbing issue at Building B', is_read=False, created_at=now - timedelta(hours=2)),
        ]
        db.session.add_all(notifs)
        db.session.commit()

        print("✅ Database seeded successfully!")
        print("   Admin:       admin@campus.edu / admin123")
        print("   Student:     student@campus.edu / student123")
        print("   Maintenance: maintenance@campus.edu / maintenance123")


if __name__ == '__main__':
    seed_database()
    print("\n🚀 Starting CampusFix on http://localhost:5000\n")
    app.run(debug=True, port=5000)
