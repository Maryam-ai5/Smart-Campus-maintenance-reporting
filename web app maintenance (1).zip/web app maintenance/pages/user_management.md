# 👥 Page 8 — User Management (Admin)

## Page Info

| Property | Value |
|---|---|
| **Route** | `/admin/users` |
| **Template** | `admin/users.html` |
| **Access** | Role: `admin` |
| **Priority** | 🟡 Medium |

---

## Purpose

Allows admins to view, add, edit roles, and deactivate user accounts across the system.

## Tech Used

- **Flask** — CRUD operations on `users` table
- **SQLite** — User queries with role filtering
- **Bootstrap 5** — Tables, modals, badges

---

## UI Components

### User Table
| Column | Details |
|--------|---------|
| ID | Auto-increment |
| Name | Full name |
| Email | Unique email |
| Role | Badge: Student / Maintenance / Admin |
| Registered | `created_at` date |
| Reports | Count of submitted reports |
| Actions | Edit Role, Deactivate |

### Search & Filter
- Search by name or email
- Filter by role dropdown

### Add User Modal
| Field | Type |
|-------|------|
| Name | Text input |
| Email | Email input |
| Password | Password input (temporary) |
| Role | Select: student / maintenance / admin |

### Edit Role Modal
- Dropdown to change user role
- Confirm button

---

## Admin Capabilities

| Action | Description |
|--------|-------------|
| View all users | Paginated list with search |
| Change role | Promote/demote user roles |
| Add user | Create maintenance/admin accounts |
| Deactivate | Soft-delete (mark inactive) |

---

## Wireframe

```
┌──────────────────────────────────────────┐
│  👥 User Management        [+ Add User]  │
├──────────────────────────────────────────┤
│ Search: [________] Role: [▾ All]         │
│                                          │
│ ┌────┬──────────┬───────────┬──────────┐ │
│ │ ID │ Name     │ Email     │ Role     │ │
│ │ 1  │ Ahmed K. │ a@uni.edu │ Student  │ │
│ │ 2  │ Sara M.  │ s@uni.edu │ Maint.   │ │
│ │ 3  │ Admin    │ admin@..  │ Admin    │ │
│ └────┴──────────┴───────────┴──────────┘ │
│                [< 1 2 3 >]               │
└──────────────────────────────────────────┘
```

---

*Smart Campus Maintenance Reporting System · User Management*
