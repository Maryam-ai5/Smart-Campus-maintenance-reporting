# 📈 Page 7 — Admin Dashboard & Analytics

## Page Info

| Property | Value |
|---|---|
| **Route** | `/admin/dashboard` |
| **Template** | `admin/dashboard.html` |
| **Access** | Role: `admin` |
| **Priority** | 🟡 Medium |

---

## Purpose

Comprehensive analytics view for administrators. Displays charts, KPIs, and system-wide report data for decision-making and performance monitoring.

## Tech Used

- **Flask** — Aggregated data queries passed to template
- **SQLite** — GROUP BY queries for analytics
- **Bootstrap 5** — Grid layout, cards
- **Chart.js** — Bar charts, pie charts, line graphs

---

## UI Components

### KPI Cards (top row)
| KPI | Calculation |
|-----|-------------|
| Total Reports | `COUNT(*)` from `reports` |
| Open Reports | `status != 'resolved'` |
| Avg Response Time | `AVG(first_update - created_at)` |
| Resolution Rate | `resolved / total * 100%` |

### Chart 1: Reports by Category (Pie Chart)
- Slices: Electrical (41.9%), HVAC (25.8%), Furniture (16.1%), Cleaning, Plumbing
- Uses Chart.js doughnut/pie

### Chart 2: Reports Over Time (Line Chart)
- X-axis: Weeks/months
- Y-axis: Number of reports
- Line: total submitted vs resolved

### Chart 3: Open vs Closed (Bar Chart)
- Grouped bar: open vs closed by category
- Color-coded bars

### Chart 4: Urgency Distribution (Horizontal Bar)
- High / Medium / Low counts

### Recent Activity Feed
- Last 10 status changes across all reports
- Format: "Report #12 moved to In Progress by Ali — 2h ago"

### Quick Actions
| Action | Link |
|--------|------|
| Manage Users | `/admin/users` |
| Configure Categories | `/admin/categories` |
| View All Reports | `/admin/reports` |

---

## Wireframe

```
┌──────────────────────────────────────────────┐
│  📊 Admin Dashboard                          │
├──────────────────────────────────────────────┤
│ [Total: 156] [Open: 23] [Avg: 4.2h] [87%]   │
│                                              │
│ ┌─────────────────┐ ┌─────────────────┐      │
│ │  By Category    │ │ Over Time       │      │
│ │   🥧 Pie Chart  │ │   📈 Line Chart │      │
│ └─────────────────┘ └─────────────────┘      │
│                                              │
│ ┌─────────────────┐ ┌─────────────────┐      │
│ │ Open vs Closed  │ │ By Urgency      │      │
│ │  📊 Bar Chart   │ │  📊 H-Bar Chart │      │
│ └─────────────────┘ └─────────────────┘      │
│                                              │
│ Recent Activity                              │
│ • #15 → In Progress (Ali, 2h ago)           │
│ • #14 → Resolved (Sara, 5h ago)             │
└──────────────────────────────────────────────┘
```

---

*Smart Campus Maintenance Reporting System · Admin Dashboard*
