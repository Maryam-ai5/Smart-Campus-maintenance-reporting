# 👤 Page 12 — Profile & Settings

## Page Info

| Property | Value |
|---|---|
| **Route** | `/profile` |
| **Template** | `profile.html` |
| **Access** | All authenticated users |
| **Priority** | 🟢 Low |

---

## Purpose

Allows users to view and update their personal information and change their password. Displays account details and activity summary.

## Tech Used

- **Flask** — GET/POST for profile updates
- **Werkzeug** — Password hashing for password change
- **SQLite** — Update `users` table
- **Bootstrap 5** — Forms, cards

---

## UI Components

### Profile Card
| Field | Display |
|-------|---------|
| Name | Editable text input |
| Email | Read-only (displayed) |
| Role | Badge (Student/Maintenance/Admin) |
| Member Since | `created_at` formatted |

### Change Password Section
| Field | Type |
|-------|------|
| Current Password | Password input |
| New Password | Password input (min 8 chars) |
| Confirm Password | Password input (must match) |
| Save | Submit button |

### Activity Summary
| Metric | Details |
|--------|---------|
| Total Reports | Count of user's reports |
| Resolved | Count of resolved reports |
| Last Activity | Date of last report or update |

---

## Wireframe

```
┌──────────────────────────────────────┐
│  👤 My Profile                       │
├──────────────────────────────────────┤
│                                      │
│  Name:   [Ahmed Khan________]        │
│  Email:  ahmed@university.edu        │
│  Role:   🎓 Student                  │
│  Since:  January 15, 2026            │
│                    [Save Changes]    │
│                                      │
│  ── Change Password ──               │
│  Current:  [________________]        │
│  New:      [________________]        │
│  Confirm:  [________________]        │
│                [Update Password]     │
│                                      │
│  ── Activity ──                      │
│  Reports: 12 | Resolved: 8          │
│  Last Active: May 14, 2026          │
└──────────────────────────────────────┘
```

---

*Smart Campus Maintenance Reporting System · Profile & Settings*
