# 🔐 Page 1 — Login & Registration

## Page Info

| Property      | Value                                    |
|---------------|------------------------------------------|
| **Route**     | `/login` · `/register`                   |
| **Template**  | `auth/login.html` · `auth/register.html` |
| **Blueprint** | `auth`                                   |
| **Access**    | Public (unauthenticated users only)      |
| **Priority**  | 🔴 High                                  |

---

## Purpose

Provide secure role-based authentication for all system users. Students, staff, maintenance personnel, and admins must log in before accessing any part of the system. New users can self-register as **Student/Staff**; other roles are assigned by the Admin.

---

## Tech Stack Used on This Page

| Technology     | Usage                                              |
|----------------|----------------------------------------------------|
| Flask          | Route handling, form processing, session management|
| Flask-Login    | `login_user()`, `logout_user()`, `login_required`  |
| Werkzeug       | `generate_password_hash()`, `check_password_hash()`|
| SQLite         | Store user records in `users` table                |
| Bootstrap 5    | Responsive form layout, cards, alerts              |
| Jinja2         | Template rendering with flash messages             |

---

## Login Page (`/login`)

### UI Elements

| Element              | Type           | Details                                      |
|----------------------|----------------|----------------------------------------------|
| Email input          | `<input>`      | type="email", required, placeholder          |
| Password input       | `<input>`      | type="password", required                    |
| "Remember Me"        | `<checkbox>`   | Optional persistent session                  |
| Login button         | `<button>`     | type="submit", Bootstrap `.btn-primary`      |
| "Forgot Password?"   | `<a>`          | Link to password reset flow                  |
| "Register" link      | `<a>`          | Redirects to `/register`                     |
| Flash messages       | Bootstrap alert| Success/error feedback                       |

### Behavior

1. User enters email and password
2. Flask validates credentials against `users` table
3. Password is verified using `check_password_hash()`
4. On success → `login_user(user)` → redirect based on role:
   - **Student/Staff** → `/dashboard`
   - **Maintenance** → `/maintenance/panel`
   - **Admin** → `/admin/dashboard`
5. On failure → flash error message, stay on login page

### Validation Rules

- Email must be valid format and exist in database
- Password must match the stored hash
- Account must be active (not archived)

---

## Registration Page (`/register`)

### UI Elements

| Element              | Type           | Details                                      |
|----------------------|----------------|----------------------------------------------|
| Full Name            | `<input>`      | type="text", required, max 100 chars         |
| Email                | `<input>`      | type="email", required, unique               |
| Password             | `<input>`      | type="password", min 8 chars                 |
| Confirm Password     | `<input>`      | type="password", must match                  |
| Register button      | `<button>`     | type="submit", Bootstrap `.btn-success`      |
| "Already registered?"| `<a>`          | Link back to `/login`                        |

### Behavior

1. User fills out registration form
2. Flask validates all fields server-side
3. Check email uniqueness in `users` table
4. Hash password with `generate_password_hash()`
5. Insert new user with `role = 'student'` (default)
6. Flash success message → redirect to `/login`

### Validation Rules

- Name: 2–100 characters, letters and spaces only
- Email: valid format, must not already exist in DB
- Password: minimum 8 characters, at least 1 letter and 1 number
- Confirm password must match password

---

## Database Interaction

### Table: `users`

```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student',  -- student | maintenance | admin
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## Security Measures

| Measure                  | Implementation                                  |
|--------------------------|-------------------------------------------------|
| Password hashing         | Werkzeug `pbkdf2:sha256`                        |
| CSRF protection          | Flask-WTF CSRF tokens on all forms              |
| Brute-force prevention   | Rate limiting on login attempts (optional)       |
| Session management       | Flask-Login secure cookie sessions              |
| Input sanitization       | Server-side validation of all inputs             |

---

## Wireframe Description

```
┌──────────────────────────────────────┐
│           🏫 Campus Maintenance      │
│                                      │
│  ┌──────────────────────────────┐    │
│  │         Login                │    │
│  │                              │    │
│  │  Email:    [_______________] │    │
│  │  Password: [_______________] │    │
│  │                              │    │
│  │  ☐ Remember Me               │    │
│  │                              │    │
│  │  [    Login    ]             │    │
│  │                              │    │
│  │  Forgot Password?            │    │
│  │  Don't have an account?      │    │
│  │  Register here               │    │
│  └──────────────────────────────┘    │
│                                      │
└──────────────────────────────────────┘
```

---

## Flask Route Snippets

```python
# auth.py blueprint
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            # Redirect based on role
            if user.role == 'admin':
                return redirect(url_for('admin.dashboard'))
            elif user.role == 'maintenance':
                return redirect(url_for('maintenance.panel'))
            else:
                return redirect(url_for('student.dashboard'))
        flash('Invalid email or password', 'danger')
    return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        # ... validation ...
        new_user = User(
            name=name,
            email=email,
            password_hash=generate_password_hash(password),
            role='student'
        )
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('auth.login'))
    return render_template('auth/register.html')
```

---

*Smart Campus Maintenance Reporting System · Login & Registration Page*
