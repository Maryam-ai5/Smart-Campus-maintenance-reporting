# 📊 Page 5 — Report Tracking Dashboard

## Page Info

| Property | Value |
|---|---|
| **Route** | `/my-reports` |
| **Template** | `student/track_reports.html` |
| **Access** | Role: `student` |
| **Priority** | 🔴 High |

---

## Purpose

Allows students/staff to see **all** their submitted reports in one place with real-time status tracking. Supports filtering and sorting to quickly find specific reports.

## Tech Used

- **Flask** — Paginated query results
- **SQLite** — Filtered queries on `reports` table
- **Bootstrap 5** — Table, badges, pagination, filter dropdowns

---

## UI Components

### Filter Bar
| Filter | Type | Options |
|--------|------|---------|
| Status | `<select>` | All, Submitted, Assigned, In Progress, Resolved |
| Category | `<select>` | All, Electrical, Plumbing, HVAC, Furniture, Cleaning |
| Urgency | `<select>` | All, High, Medium, Low |
| Date Range | Date pickers | From / To |
| Apply | `<button>` | Refreshes table |

### Reports Table
| Column | Details |
|--------|---------|
| # | Report ID |
| Category | Icon + text |
| Location | Building/room |
| Urgency | Color badge |
| Status | Progress badge |
| Submitted | Date |
| Last Update | Date |
| Action | "View" → `/report/<id>` |

### Status Progress Indicator
For each report row, a visual mini-progress bar:
```
[██████████░░░░░░░░░░] Assigned (Step 2/4)
```

### Pagination
- 10 reports per page
- Previous / Next + page numbers

---

## Real-Time Status Flow

```
Submitted ──→ Assigned ──→ In Progress ──→ Resolved
   (1)           (2)           (3)            (4)
```

Each stage is color-coded:
- **Submitted**: 🟠 Orange
- **Assigned**: 🟡 Yellow
- **In Progress**: 🔵 Blue
- **Resolved**: 🟢 Green

---

## Wireframe

```
┌────────────────────────────────────────────┐
│  My Reports                                │
├────────────────────────────────────────────┤
│ Status: [▾ All] Category: [▾ All]          │
│ Urgency: [▾ All] Date: [From] - [To]      │
│                            [Apply Filters] │
│                                            │
│ ┌──┬──────────┬────────┬──────┬──────────┐ │
│ │# │ Category │Location│Urgency│ Status  │ │
│ │12│ Electric │Block A │ High │ ██░░ Asgn│ │
│ │11│ HVAC     │Lab 201 │ Med  │ ███░ InPr│ │
│ │10│ Furniture│Library │ Low  │ ████ Done│ │
│ └──┴──────────┴────────┴──────┴──────────┘ │
│              [< 1  2  3 >]                 │
└────────────────────────────────────────────┘
```

---

*Smart Campus Maintenance Reporting System · Report Tracking Dashboard*
