# ⚙️ Page 9 — Category Management (Admin)

## Page Info

| Property | Value |
|---|---|
| **Route** | `/admin/categories` |
| **Template** | `admin/categories.html` |
| **Access** | Role: `admin` |
| **Priority** | 🟡 Medium |

---

## Purpose

Allows admins to configure and manage the issue categories available in the submission form. Admins can add new categories, edit existing ones, or disable them.

## Tech Used

- **Flask** — CRUD routes for categories
- **SQLite** — `categories` table (or hardcoded list with admin override)
- **Bootstrap 5** — Cards, forms, toggle switches

---

## Default Categories

| Category | Icon | Survey Share |
|----------|------|-------------|
| Electrical | ⚡ | 41.9% |
| Air Conditioning / HVAC | ❄️ | 25.8% |
| Furniture | 🪑 | 16.1% |
| Cleaning / Hygiene | 🧹 | ~16.2% |
| Plumbing | 🔧 | — |

---

## UI Components

### Category List
| Column | Details |
|--------|---------|
| Icon | Emoji or icon class |
| Name | Category name |
| Reports Count | How many reports use this category |
| Status | Active / Inactive toggle |
| Actions | Edit, Disable |

### Add/Edit Category Modal
| Field | Type |
|-------|------|
| Category Name | Text input |
| Icon | Emoji picker or text |
| Description | Optional textarea |
| Active | Toggle switch |

---

## Wireframe

```
┌──────────────────────────────────────────┐
│  ⚙️ Category Management  [+ Add Category]│
├──────────────────────────────────────────┤
│                                          │
│ ┌──────┬──────────────┬───────┬────────┐ │
│ │ Icon │ Category     │Reports│ Status │ │
│ │ ⚡    │ Electrical   │  65   │ ✅ On  │ │
│ │ ❄️    │ HVAC         │  40   │ ✅ On  │ │
│ │ 🪑    │ Furniture    │  25   │ ✅ On  │ │
│ │ 🧹    │ Cleaning     │  18   │ ✅ On  │ │
│ │ 🔧    │ Plumbing     │   8   │ ✅ On  │ │
│ └──────┴──────────────┴───────┴────────┘ │
│                                          │
└──────────────────────────────────────────┘
```

---

*Smart Campus Maintenance Reporting System · Category Management*
