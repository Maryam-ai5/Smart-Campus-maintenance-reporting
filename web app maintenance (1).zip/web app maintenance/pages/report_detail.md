# 🔍 Page 4 — Report Detail View

## Page Info

| Property | Value |
|---|---|
| **Route** | `/report/<int:id>` |
| **Template** | `student/report_detail.html` |
| **Access** | Owner (student), Maintenance, Admin |
| **Priority** | 🔴 High |

---

## Purpose

Displays full details of a single maintenance report including status timeline, uploaded photo, and all update notes from the maintenance team.

## Tech Used

- **Flask** — Dynamic route with report ID
- **SQLite** — Join `reports`, `report_updates`, `users`
- **Bootstrap 5** — Cards, timeline component, image viewer

---

## UI Sections

### Report Header
| Field | Display |
|-------|---------|
| Report ID | `#{{ report.id }}` |
| Status | Color badge (Submitted/Assigned/In Progress/Resolved) |
| Submitted by | Reporter name |
| Date | Formatted `created_at` |

### Report Details Card
| Field | Value |
|-------|-------|
| Category | Icon + name (e.g. ⚡ Electrical) |
| Location | Building + room |
| Urgency | Colored badge |
| Description | Full text |
| Photo | Clickable thumbnail → lightbox (if uploaded) |

### Status Timeline
Visual vertical timeline showing each status change:
```
● Submitted — May 10, 2026 10:30 AM
│  "Report created by Ahmed"
● Assigned — May 10, 2026 2:15 PM
│  "Assigned to Electrical Team"
● In Progress — May 11, 2026 9:00 AM
│  "Technician inspecting wiring in Block A"
○ Resolved — (pending)
```

Each entry comes from `report_updates` table.

### Action Buttons (role-based)
| Role | Actions |
|------|---------|
| Student (owner) | View only; can add comment |
| Maintenance | Update status, add resolution note |
| Admin | All above + reopen ticket, reassign |

---

## Database Queries

```sql
-- Get report details
SELECT r.*, u.name as reporter_name
FROM reports r JOIN users u ON r.user_id = u.id
WHERE r.id = ?;

-- Get all updates/timeline
SELECT ru.*, u.name as updater_name
FROM report_updates ru JOIN users u ON ru.updated_by = u.id
WHERE ru.report_id = ? ORDER BY ru.timestamp ASC;
```

---

## Wireframe

```
┌──────────────────────────────────────┐
│  Report #12          [🟡 Assigned]   │
│  By: Ahmed  •  May 10, 2026         │
├──────────────────────────────────────┤
│  Category:  ⚡ Electrical            │
│  Location:  Block A, Room 102       │
│  Urgency:   🔴 High                 │
│                                      │
│  Description:                        │
│  Power outlet not working near...    │
│                                      │
│  📷 [Attached Photo Thumbnail]       │
├──────────────────────────────────────┤
│  Status Timeline                     │
│  ● Submitted — May 10, 10:30 AM     │
│  │  Report created                   │
│  ● Assigned — May 10, 2:15 PM       │
│  │  Assigned to Electrical Team      │
│  ○ In Progress — (pending)          │
│  ○ Resolved — (pending)             │
└──────────────────────────────────────┘
```

---

*Smart Campus Maintenance Reporting System · Report Detail Page*
