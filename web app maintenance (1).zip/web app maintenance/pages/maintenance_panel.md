# 🔧 Page 6 — Maintenance Team Panel

## Page Info

| Property | Value |
|---|---|
| **Route** | `/maintenance/panel` |
| **Template** | `maintenance/panel.html` |
| **Access** | Role: `maintenance` |
| **Priority** | 🔴 High |

---

## Purpose

Central workspace for the maintenance team to view, manage, and resolve assigned tickets. Provides a filterable queue with one-click status updates and resolution notes.

## Tech Used

- **Flask** — Route handling, POST for status updates
- **SQLite** — Query all reports assigned to maintenance team
- **Bootstrap 5** — Tables, modals, dropdowns, badges

---

## UI Components

### Summary Bar
| Metric | Query |
|--------|-------|
| Open Tickets | `status IN ('submitted','assigned','in_progress')` |
| High Priority | `urgency = 'high' AND status != 'resolved'` |
| Resolved Today | `status = 'resolved' AND DATE(updated_at) = TODAY` |

### Filter Controls
| Filter | Options |
|--------|---------|
| Category | Electrical, Plumbing, HVAC, Furniture, Cleaning |
| Priority | High, Medium, Low |
| Status | Submitted, Assigned, In Progress, Resolved |
| Sort | Newest, Oldest, Highest Priority |

### Ticket Queue Table
| Column | Details |
|--------|---------|
| # | Report ID |
| Category | Icon + text |
| Location | Building/room |
| Reporter | Student name |
| Urgency | Priority badge |
| Status | Dropdown to change status ← **one-click update** |
| Submitted | Date |
| Action | "View" + "Add Note" buttons |

### Status Update Modal (on "Add Note")
| Field | Type |
|-------|------|
| New Status | `<select>`: Assigned / In Progress / Resolved |
| Resolution Note | `<textarea>`: max 500 chars |
| Save | Inserts into `report_updates`, updates `reports.status` |

---

## Key Feature: One-Click Status Update

Maintenance staff can change a ticket's status directly from the table dropdown:
1. Select new status from inline dropdown
2. Flask POST request updates `reports.status` and `reports.updated_at`
3. Creates entry in `report_updates` table
4. Triggers notification to reporter
5. Page refreshes with updated status

---

## Database Operations

```sql
-- Update report status
UPDATE reports SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?;

-- Insert update record
INSERT INTO report_updates (report_id, updated_by, status, note, timestamp)
VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP);

-- Create notification for reporter
INSERT INTO notifications (user_id, report_id, message, is_read, created_at)
VALUES (?, ?, ?, 0, CURRENT_TIMESTAMP);
```

---

## Wireframe

```
┌──────────────────────────────────────────────┐
│  🔧 Maintenance Panel                        │
├──────────────────────────────────────────────┤
│ [Open: 15] [🔴 High Priority: 4] [Done: 3]  │
│                                              │
│ Category: [▾] Priority: [▾] Status: [▾]     │
│                                              │
│ ┌──┬──────────┬────────┬────────┬──────────┐ │
│ │# │ Category │ Place  │Urgency │ Status ▾ │ │
│ │15│ Electric │Block C │ 🔴 High│[Assigned]│ │
│ │14│ Plumbing │Bldg B  │ 🟡 Med │[InProgrs]│ │
│ │13│ HVAC     │Hall 1  │ 🔴 High│[Submittd]│ │
│ └──┴──────────┴────────┴────────┴──────────┘ │
│                                              │
│  [Add Resolution Note]  ← opens modal       │
└──────────────────────────────────────────────┘
```

---

*Smart Campus Maintenance Reporting System · Maintenance Panel*
