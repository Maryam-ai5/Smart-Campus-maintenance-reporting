# 🔔 Page 10 — Notifications Center

## Page Info

| Property | Value |
|---|---|
| **Route** | `/notifications` |
| **Template** | `notifications.html` |
| **Access** | All authenticated users |
| **Priority** | 🔴 High |

---

## Purpose

Centralized inbox for all system notifications. Users receive alerts when report statuses change, new high-priority issues are submitted (maintenance), or admin actions occur.

## Tech Used

- **Flask** — Query and mark-as-read endpoints
- **SQLite** — `notifications` table with `is_read` flag
- **Bootstrap 5** — List group, badges, icons

---

## Notification Types

| Trigger | Recipient | Message Example |
|---------|-----------|-----------------|
| Report submitted | Admin | "New report #15 submitted (🔴 High)" |
| Status changed | Reporter | "Report #12 moved to In Progress" |
| Report resolved | Reporter | "Report #12 has been resolved" |
| Report reopened | Maintenance | "Report #12 reopened by Admin" |
| High priority submitted | Maintenance | "⚠️ High priority: Electrical issue in Block A" |

---

## UI Components

### Notification List
| Element | Details |
|---------|---------|
| Icon | 🔵 unread / ⚪ read |
| Message | Notification text |
| Report Link | Clickable → `/report/<id>` |
| Timestamp | "2 hours ago", "May 14, 2026" |
| Mark Read | Button or click-to-dismiss |

### Top Bar
- "Mark All as Read" button
- Unread count badge
- Filter: All / Unread only

---

## Database

```sql
CREATE TABLE notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    report_id INTEGER,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (report_id) REFERENCES reports(id)
);
```

### Queries
```sql
-- Get user notifications (newest first)
SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC;

-- Mark as read
UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?;

-- Mark all as read
UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0;

-- Unread count
SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0;
```

---

## Wireframe

```
┌──────────────────────────────────────────┐
│  🔔 Notifications (3 unread)  [Mark All] │
├──────────────────────────────────────────┤
│ Filter: [All ▾]                          │
│                                          │
│ 🔵 Report #15 moved to In Progress      │
│    2 hours ago                  [View →] │
│                                          │
│ 🔵 New high priority report in Block A   │
│    5 hours ago                  [View →] │
│                                          │
│ 🔵 Report #12 has been resolved          │
│    1 day ago                    [View →] │
│                                          │
│ ⚪ Report #10 assigned to Electrical     │
│    3 days ago                   [View →] │
└──────────────────────────────────────────┘
```

---

*Smart Campus Maintenance Reporting System · Notifications*
