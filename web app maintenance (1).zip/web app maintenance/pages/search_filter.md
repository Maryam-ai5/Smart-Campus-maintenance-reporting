# 🔎 Page 11 — Search & Filter

## Page Info

| Property | Value |
|---|---|
| **Route** | `/search` |
| **Template** | `search.html` |
| **Access** | All authenticated users (scoped by role) |
| **Priority** | 🟡 Medium |

---

## Purpose

Global search and advanced filtering for tickets. Students see only their own; maintenance and admin see all reports. Supports keyword search, multi-filter combinations, and date ranges.

## Tech Used

- **Flask** — GET request with query parameters
- **SQLite** — `LIKE` search + `WHERE` clause filters
- **Bootstrap 5** — Search bar, filter panel, results table

---

## Search Capabilities

| Feature | Implementation |
|---------|---------------|
| Keyword search | `LIKE '%keyword%'` on `description`, `location` |
| Category filter | `WHERE category = ?` |
| Status filter | `WHERE status = ?` |
| Urgency filter | `WHERE urgency = ?` |
| Date range | `WHERE created_at BETWEEN ? AND ?` |
| Location filter | `LIKE '%location%'` |
| Combined filters | All filters AND-combined |

---

## UI Components

### Search Bar
- Full-width text input with search icon
- Placeholder: "Search by keyword, location, description..."
- Submit on Enter or click

### Advanced Filters Panel (collapsible)
| Filter | Type | Options |
|--------|------|---------|
| Category | Multi-select | All categories |
| Status | Checkbox group | Submitted, Assigned, In Progress, Resolved |
| Urgency | Radio buttons | High, Medium, Low, All |
| Date From | Date picker | Calendar input |
| Date To | Date picker | Calendar input |
| Location | Text input | Partial match |

### Results Display
- Result count: "Showing 15 results for 'Block A'"
- Same table format as Report Tracking page
- Pagination: 10 per page

---

## Role-Based Scoping

| Role | Sees |
|------|------|
| Student | Only own reports |
| Maintenance | All open tickets |
| Admin | All reports (open + archived) |

---

## Wireframe

```
┌──────────────────────────────────────────┐
│  🔎 Search Reports                       │
├──────────────────────────────────────────┤
│ [🔍 Search by keyword...        ] [Go]   │
│                                          │
│ ▸ Advanced Filters                       │
│   Category: [▾] Status: [☐☐☐☐]         │
│   Urgency: [○ All ● High ○ Med ○ Low]   │
│   Date: [From ___] to [To ___]          │
│                        [Apply Filters]   │
│                                          │
│ Showing 15 results                       │
│ ┌──┬──────────┬────────┬──────┬────────┐ │
│ │# │ Category │Location│Status│ Date   │ │
│ │15│ Electric │Block A │ Open │ May 14 │ │
│ │12│ Electric │Block A │ Done │ May 10 │ │
│ └──┴──────────┴────────┴──────┴────────┘ │
│              [< 1 2 >]                   │
└──────────────────────────────────────────┘
```

---

*Smart Campus Maintenance Reporting System · Search & Filter*
