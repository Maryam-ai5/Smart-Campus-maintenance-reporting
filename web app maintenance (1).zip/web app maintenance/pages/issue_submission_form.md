# 📝 Page 3 — Issue Submission Form

## Page Info

| Property | Value |
|---|---|
| **Route** | `/submit-report` |
| **Template** | `student/submit_report.html` |
| **Access** | Role: `student` |
| **Priority** | 🔴 High |

---

## Purpose

Main form for students/staff to report a campus maintenance issue. Collects category, location, description, urgency level, and optional photo upload.

## Tech Used

- **Flask** — Form processing, file upload handling
- **SQLite** — Insert into `reports` table
- **Bootstrap 5** — Form controls, validation styles
- **Werkzeug** — `secure_filename()` for uploads

---

## Form Fields

| Field | Type | Required | Options/Constraints |
|-------|------|----------|---------------------|
| Category | `<select>` | ✅ | Electrical, Plumbing, HVAC, Furniture, Cleaning |
| Location | `<input text>` | ✅ | Building name + room (e.g. "Block A, Room 201") |
| Description | `<textarea>` | ✅ | Min 20, max 1000 characters |
| Urgency | `<select>` | ✅ | Low, Medium, High |
| Photo | `<input file>` | ❌ | JPG/PNG, max 5MB |
| Submit | `<button>` | — | Saves to DB, redirects |

---

## Behavior

1. User fills all required fields
2. Client-side Bootstrap validation highlights errors
3. On submit → Flask validates server-side
4. Photo saved to `static/uploads/` with unique filename
5. New row inserted into `reports` table with `status='submitted'`
6. Notification created for admin
7. Flash success → redirect to `/dashboard`

---

## Validation

| Field | Rule |
|-------|------|
| Category | Must be from predefined list |
| Location | 3–200 characters |
| Description | 20–1000 characters |
| Urgency | Must be low/medium/high |
| Photo | Optional; if provided: JPG/PNG only, ≤ 5MB |

---

## Database Insert

```sql
INSERT INTO reports (user_id, category, location, description, urgency, photo_path, status)
VALUES (?, ?, ?, ?, ?, ?, 'submitted');
```

---

## Wireframe

```
┌────────────────────────────────────┐
│  Submit Maintenance Report         │
├────────────────────────────────────┤
│                                    │
│  Category:  [▾ Select category  ]  │
│                                    │
│  Location:  [__________________ ]  │
│                                    │
│  Description:                      │
│  ┌──────────────────────────────┐  │
│  │                              │  │
│  │                              │  │
│  └──────────────────────────────┘  │
│                                    │
│  Urgency:   [▾ Select urgency  ]   │
│                                    │
│  Photo:     [Choose File]          │
│                                    │
│        [ Submit Report ]           │
└────────────────────────────────────┘
```

---

*Smart Campus Maintenance Reporting System · Issue Submission Form*
