# 🎓 Page 2 — Student / Staff Dashboard

## Page Info

| Property | Value |
|---|---|
| **Route** | `/dashboard` |
| **Template** | `student/dashboard.html` |
| **Access** | Role: `student` |
| **Priority** | 🔴 High |

---

## Purpose

Primary landing page for students/staff after login. Shows submitted reports overview, statuses, and quick actions.

## Tech Used

- **Flask** — Route handling, `@login_required`
- **Flask-Login** — `current_user` context
- **SQLite** — Query `reports` & `notifications`
- **Bootstrap 5** — Cards, badges, responsive grid

---

## UI Components

### Welcome Header
- Greeting: "Welcome back, {{ name }}"
- "Submit New Report" CTA button

### Summary Cards (4 across)
| Card | Query | Color |
|------|-------|-------|
| Total Reports | `COUNT(*)` | Blue |
| Pending | `status='submitted'` | Yellow |
| In Progress | `status='in_progress'` | Blue |
| Resolved | `status='resolved'` | Green |

### Recent Reports Table (last 10)
| Column | Details |
|--------|---------|
| Report ID | Clickable → detail page |
| Category | ⚡ Electrical, ❄️ HVAC, etc. |
| Location | Building / room |
| Urgency | 🔴 High / 🟡 Medium / 🟢 Low |
| Status | Color-coded badge |
| Date | Formatted `created_at` |

### Notification Bell
- Badge showing unread count
- Last 5 notifications dropdown

---

## Wireframe

```
┌────────────────────────────────────────────┐
│  🏫 Campus Maintenance   [🔔 3] [Profile] │
├────────────────────────────────────────────┤
│ Welcome, Ahmed!        [+ Submit Report]   │
│                                            │
│ [Total: 12] [Pending: 3] [Active: 5] [4]  │
│                                            │
│ Recent Reports               [View All →]  │
│ ┌────┬───────────┬────────┬───────┬──────┐ │
│ │ #  │ Category  │ Place  │ Urg.  │Status│ │
│ │ 12 │ Electric  │ Blk A  │ High  │ Asgn │ │
│ │ 11 │ HVAC      │ Lab201 │ Med   │ InPr │ │
│ └────┴───────────┴────────┴───────┴──────┘ │
└────────────────────────────────────────────┘
```

---

## Responsive Behavior
- **Desktop**: 4 cards in row, full table
- **Tablet**: 2 cards/row, scrollable table
- **Mobile**: 1 card/row, card-based list

---

*Smart Campus Maintenance Reporting System · Student Dashboard*
